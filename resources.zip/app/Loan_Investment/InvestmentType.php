<?php

namespace App\Loan_Investment;

use Illuminate\Database\Eloquent\Model;

class InvestmentType extends Model
{
    protected $fillable = ['type_name'];
}
